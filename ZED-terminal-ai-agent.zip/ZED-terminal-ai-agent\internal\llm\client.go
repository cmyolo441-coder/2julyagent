package llm

import (
	"context"
	"fmt"

	"github.com/gjkjk/zed/internal/config"
)

// Client is a provider-agnostic LLM interface. Implementations stream events
// over the returned channel and close it when finished.
type Client interface {
	// Name returns the provider identifier.
	Name() string
	// Stream sends a request and returns a channel of streaming events.
	Stream(ctx context.Context, req Request) (<-chan StreamEvent, error)
}

// New builds a Client from config, selecting the correct provider.
func New(cfg *config.Config) (Client, error) {
	switch cfg.Provider {
	case "anthropic", "":
		return newAnthropic(cfg), nil
	case "openai":
		return newOpenAI(cfg), nil
	default:
		return nil, fmt.Errorf("unknown provider %q", cfg.Provider)
	}
}
