# myagent.ps1 — Launch ZED terminal AI agent from anywhere.
# Usage:  myagent
#         myagent --model big-pickle
#         myagent /goal "build a web scraper"

$ZedDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Default config — override with env vars or pass --model flag.
# Only set defaults if config.json doesn't exist yet.
$cfgPath = Join-Path ([Environment]::GetFolderPath("ApplicationData")) "Zed\config.json"
if (-not (Test-Path $cfgPath)) {
    $env:ZED_PROVIDER = if ($env:ZED_PROVIDER) { $env:ZED_PROVIDER } else { "openai" }
    $env:ZED_BASE_URL = if ($env:ZED_BASE_URL) { $env:ZED_BASE_URL } else { "https://opencode.ai/zen/v1/chat/completions" }
    $env:ZED_MODEL    = if ($env:ZED_MODEL) { $env:ZED_MODEL } else { "mimo-v2.5-free" }
}

# Check API key.
if (-not $env:ZED_API_KEY) {
    Write-Host "  ZED_API_KEY is not set." -ForegroundColor Yellow
    Write-Host '  Run:  $env:ZED_API_KEY = "your-key-here"' -ForegroundColor Yellow
    Write-Host "  Or add it to your PowerShell profile permanently." -ForegroundColor Yellow
    exit 1
}

# Build if needed.
$exe = Join-Path $ZedDir "zed.exe"
if (-not (Test-Path $exe)) {
    Write-Host "  Building zed.exe ..." -ForegroundColor Cyan
    Push-Location $ZedDir
    go build -o zed.exe ./cmd/zed
    Pop-Location
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

# Pass arguments to zed.exe (e.g. --model, /goal, etc.)
& $exe @args
