package config

import "strings"

// Effort selects how hard ZED works on a task. Higher levels unlock deeper
// reasoning, more ReAct iterations, larger token budgets, up-front planning,
// and self-verification loops — trading speed and cost for capability on
// increasingly complex, real-world projects.
type Effort struct {
	// Name is the canonical identifier (also the /command alias).
	Name string
	// Label is a short human-friendly title shown in the UI.
	Label string
	// Multiplier is a rough "how much more advanced" factor vs. normal,
	// used purely for display (e.g. "40×").
	Multiplier int
	// MaxSteps caps the ReAct loop for this level.
	MaxSteps int
	// MaxTokens caps output tokens per model turn.
	MaxTokens int
	// FastModel overrides the primary model when set. Goal mode and similar
	// long-running levels benefit from a fast, cheap model for low latency.
	FastModel string
	// PlanFirst makes the agent produce a structured plan before acting.
	PlanFirst bool
	// SelfVerify makes the agent build/test its own work and fix regressions.
	SelfVerify bool
	// DeepResearch makes the agent investigate the codebase end-to-end first.
	DeepResearch bool
	// GoalMode turns on fully autonomous, end-to-end goal execution.
	GoalMode bool
	// Description is a one-line summary of when to use this level.
	Description string
}

// Effort level names. These double as slash-command aliases.
const (
	EffortNormal        = "normal"
	EffortUltra         = "ultraeffort"
	EffortUltraMax      = "ultramax"
	EffortUltraComboMax = "ultracombomax"
	EffortGoal          = "goal"
)

// DefaultEffort is used when nothing is configured.
const DefaultEffort = EffortNormal

// efforts is the ordered catalog of available effort levels.
var efforts = []Effort{
	{
		Name:        EffortNormal,
		Label:       "Normal",
		Multiplier:  1,
		MaxSteps:    25,
		MaxTokens:   128000,
		Description: "Fast, balanced. Everyday edits, questions, and small tasks.",
	},
	{
		Name:        EffortUltra,
		Label:       "Ultra Effort",
		Multiplier:  1,
		MaxSteps:    60,
		MaxTokens:   128000,
		PlanFirst:   true,
		SelfVerify:  true,
		Description: "Deep reasoning + planning + self-verify. For advanced, complex projects.",
	},
	{
		Name:         EffortUltraMax,
		Label:        "Ultra Max",
		Multiplier:   40,
		MaxSteps:     150,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		Description:  "40× — exhaustive planning, research, and verification for large complex systems.",
	},
	{
		Name:         EffortUltraComboMax,
		Label:        "Ultra Combo Max",
		Multiplier:   100,
		MaxSteps:     300,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		Description:  "100× — enterprise-grade, real-world autonomous engineering at maximum depth.",
	},
	{
		Name:         EffortGoal,
		Label:        "Goal Mode",
		Multiplier:   100,
		MaxSteps:     500,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		GoalMode:     true,
		Description:  "100× — Ultra Combo Max + autonomous goal execution. Researches, plans, builds end-to-end, self-detects and fixes bugs.",
	},
}

// Efforts returns the catalog of effort levels in display order.
func Efforts() []Effort { return efforts }

// LookupEffort returns the effort profile for a name (case-insensitive).
// The second return value reports whether the name was recognized.
func LookupEffort(name string) (Effort, bool) {
	n := strings.ToLower(strings.TrimSpace(name))
	for _, e := range efforts {
		if e.Name == n {
			return e, true
		}
	}
	return efforts[0], false
}

// EffortProfile returns the profile for a name, falling back to Normal.
func EffortProfile(name string) Effort {
	e, _ := LookupEffort(name)
	return e
}
