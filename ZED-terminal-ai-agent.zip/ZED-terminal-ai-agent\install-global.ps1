# install-global.ps1 — Make 'myagent' available system-wide on Windows.
# Run this ONCE:
#   cd C:\Users\hcmad\Desktop\zed1
#   .\install-global.ps1
#
# After that, open a NEW terminal and type:
#   myagent
#   myagent --model big-pickle
#   myagent /goal "build me a web scraper"

$ZedDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# --- Step 1: Create the myagent.bat shim in a persistent location ---
$shimDir = Join-Path $env:USERPROFILE ".local\bin"
if (-not (Test-Path $shimDir)) {
    New-Item -ItemType Directory -Path $shimDir -Force | Out-Null
    Write-Host "  Created: $shimDir" -ForegroundColor Green
}

$batPath = Join-Path $shimDir "myagent.bat"
$batContent = @"
@echo off
powershell -ExecutionPolicy Bypass -NoProfile -File "$ZedDir\myagent.ps1" %*
"@
Set-Content -Path $batPath -Value $batContent -Encoding ASCII
Write-Host "  Created: $batPath" -ForegroundColor Green

# --- Step 2: Add to user PATH (persistent, survives reboot) ---
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$shimDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$shimDir;$userPath", "User")
    $env:Path = "$shimDir;$env:Path"
    Write-Host "  Added $shimDir to user PATH" -ForegroundColor Green
} else {
    Write-Host "  $shimDir already in PATH" -ForegroundColor DarkGray
}

# --- Step 3: Add ZED_API_KEY to PowerShell profile (if not already there) ---
$profilePath = $PROFILE.CurrentUserAllHosts
$profileDir  = Split-Path $profilePath
if (-not (Test-Path $profileDir)) {
    New-Item -ItemType Directory -Path $profileDir -Force | Out-Null
}

$marker = "# ZED Agent config"
$apiKey = $env:ZED_API_KEY
if (-not $apiKey) {
    Write-Host ""
    Write-Host "  No ZED_API_KEY set in current session." -ForegroundColor Yellow
    $apiKey = Read-Host "  Enter your ZED API key (or press Enter to skip)"
}

$profileContent = ""
if (Test-Path $profilePath) {
    $profileContent = Get-Content $profilePath -Raw
}

if ($profileContent -notlike "*$marker*") {
    $newBlock = @"

$marker
`$env:ZED_API_KEY    = "$apiKey"
`$env:ZED_PROVIDER   = "openai"
`$env:ZED_BASE_URL   = "https://opencode.ai/zen/v1/chat/completions"
`$env:ZED_MODEL      = "mimo-v2.5-free"
"@
    Add-Content -Path $profilePath -Value $newBlock
    Write-Host "  Added ZED config to $profilePath" -ForegroundColor Green
} else {
    Write-Host "  ZED config already in PowerShell profile" -ForegroundColor DarkGray
}

# --- Done ---
Write-Host ""
Write-Host "  ==============================================" -ForegroundColor Cyan
Write-Host "   ZED Agent installed successfully!" -ForegroundColor Green
Write-Host "   " -ForegroundColor Cyan
Write-Host "   Close this terminal and open a NEW one." -ForegroundColor White
Write-Host "   Then just type:  myagent" -ForegroundColor White
Write-Host "   ==============================================" -ForegroundColor Cyan
Write-Host ""
