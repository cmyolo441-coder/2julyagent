package main

import (
	"fmt"
	"os"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/gjkjk/zed/internal/agent"
	"github.com/gjkjk/zed/internal/config"
	"github.com/gjkjk/zed/internal/index"
	"github.com/gjkjk/zed/internal/llm"
	"github.com/gjkjk/zed/internal/logging"
	"github.com/gjkjk/zed/internal/security"
	"github.com/gjkjk/zed/internal/session"
	"github.com/gjkjk/zed/internal/snapshot"
	"github.com/gjkjk/zed/internal/tools"
	"github.com/gjkjk/zed/internal/tui"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "zed:", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	// Allow simple CLI overrides: zed --model X --provider Y
	parseFlags(cfg)

	if cfg.APIKey == "" {
		return fmt.Errorf("no API key set (export ZED_API_KEY or ANTHROPIC_API_KEY / OPENAI_API_KEY)")
	}

	// Structured file logging (never writes to the TUI's terminal).
	logger, err := logging.New(logging.Options{Level: logging.LevelInfo})
	if err != nil {
		return fmt.Errorf("init logging: %w", err)
	}
	defer logger.Close()
	logger.Info("zed starting", logging.F("provider", cfg.Provider), logging.F("model", cfg.Model))

	client, err := llm.New(cfg)
	if err != nil {
		return fmt.Errorf("init llm: %w", err)
	}

	// Enterprise subsystems.
	snapshots := snapshot.NewManager(200)
	policy := security.DefaultPolicy(cfg.WorkDir, cfg.AutoApply)
	sessions, err := session.NewStore("")
	if err != nil {
		logger.Warn("session store unavailable", logging.F("err", err.Error()))
	}

	// Build the codebase index in the background so startup stays fast.
	idx := index.New(cfg.WorkDir)
	go func() {
		stats, err := idx.Build()
		if err != nil {
			logger.Warn("index build failed", logging.F("err", err.Error()))
			return
		}
		logger.Info("index built",
			logging.F("files", stats.Files),
			logging.F("symbols", stats.Symbols),
			logging.F("ms", stats.Duration.Milliseconds()))
	}()

	registry := buildRegistry(cfg, snapshots, idx)
	ag := agent.New(cfg, client, registry)
	ag.SetSnapshots(snapshots)
	ag.SetPolicy(policy)
	ag.SetLogger(logger)

	model := tui.NewModel(cfg, ag, snapshots, sessions, idx)
	// Note: we deliberately do NOT enable mouse capture (WithMouseCellMotion).
	// Capturing the mouse prevents the terminal's native text selection, so
	// users couldn't select/copy text. Leaving it off restores normal
	// click-drag selection and copy (Ctrl/Cmd+C, or the terminal's copy).
	p := tea.NewProgram(model, tea.WithAltScreen())
	_, err = p.Run()
	return err
}

// buildRegistry registers every tool the agent can use.
func buildRegistry(cfg *config.Config, snapshots *snapshot.Manager, idx *index.Index) *tools.Registry {
	r := tools.NewRegistry()
	wd := cfg.WorkDir
	r.Register(&tools.ReadFile{WorkDir: wd})
	r.Register(&tools.WriteFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.AppendFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.EditFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.ListDir{WorkDir: wd})
	r.Register(&tools.Grep{WorkDir: wd})
	r.Register(&tools.FindFiles{WorkDir: wd})
	r.Register(&tools.CodeSearch{Index: idx})
	r.Register(&tools.SymbolLookup{Index: idx})
	r.Register(&tools.Shell{WorkDir: wd, Timeout: 4000 * time.Second})
	return r
}

// parseFlags applies minimal command-line overrides.
func parseFlags(cfg *config.Config) {
	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--model":
			if i+1 < len(args) {
				cfg.Model = args[i+1]
				i++
			}
		case "--provider":
			if i+1 < len(args) {
				cfg.Provider = args[i+1]
				i++
			}
		}
	}
}
