package agent

import (
	"context"
	"encoding/json"
	"time"

	appctx "github.com/gjkjk/zed/internal/context"
	"github.com/gjkjk/zed/internal/config"
	"github.com/gjkjk/zed/internal/llm"
	"github.com/gjkjk/zed/internal/logging"
	"github.com/gjkjk/zed/internal/retry"
	"github.com/gjkjk/zed/internal/security"
	"github.com/gjkjk/zed/internal/snapshot"
	"github.com/gjkjk/zed/internal/tools"
)

// EventKind classifies an event streamed out of the agent.
type EventKind int

const (
	EventText     EventKind = iota // incremental assistant text
	EventToolCall                  // agent is about to run a tool
	EventToolDone                  // a tool finished, carries its result
	EventDone                      // the whole turn is complete
	EventError                     // fatal error
)

// Event is emitted by the agent so the UI can render progress live.
type Event struct {
	Kind     EventKind
	Text     string       // for EventText / EventError
	ToolName string       // for EventToolCall / EventToolDone
	ToolArgs string       // for EventToolCall
	Result   string       // for EventToolDone
	IsError  bool         // for EventToolDone
	Usage    *llm.Usage   // for EventDone
}

// Agent runs the ReAct loop: it calls the LLM, executes any requested tools,
// feeds results back, and repeats until the model stops calling tools.
type Agent struct {
	cfg       *config.Config
	client    llm.Client
	registry  *tools.Registry
	history   []llm.Message
	system    string
	snapshots *snapshot.Manager
	policy    *security.Policy
	logger    *logging.Logger
	ctxMgr    *appctx.Manager
	retryPol  retry.Policy
	effort    config.Effort
}

// New builds an Agent with a fresh conversation history.
func New(cfg *config.Config, client llm.Client, registry *tools.Registry) *Agent {
	effort := config.EffortProfile(cfg.Effort)
	system := SystemPrompt(cfg.WorkDir, effort)
	return &Agent{
		cfg:      cfg,
		client:   client,
		registry: registry,
		system:   system,
		logger:   logging.Nop(),
		ctxMgr:   appctx.NewManager(system, appctx.DefaultBudget(), nil),
		retryPol: retry.DefaultPolicy(),
		effort:   effort,
	}
}

// SetEffort switches the agent's effort level, rebuilding the system prompt so
// subsequent turns use the new reasoning depth, planning, and verification
// behavior. The change takes effect on the next Run.
func (a *Agent) SetEffort(e config.Effort) {
	a.effort = e
	a.system = SystemPrompt(a.cfg.WorkDir, e)
	a.ctxMgr = appctx.NewManager(a.system, appctx.DefaultBudget(), nil)
}

// Effort returns the agent's current effort profile.
func (a *Agent) Effort() config.Effort { return a.effort }

// SetSnapshots attaches an undo/redo manager.
func (a *Agent) SetSnapshots(m *snapshot.Manager) { a.snapshots = m }

// SetPolicy attaches the security policy.
func (a *Agent) SetPolicy(p *security.Policy) { a.policy = p }

// SetLogger attaches a structured logger.
func (a *Agent) SetLogger(l *logging.Logger) {
	if l != nil {
		a.logger = l
	}
}

// LoadHistory replaces the conversation (used when resuming a session).
func (a *Agent) LoadHistory(msgs []llm.Message) { a.history = msgs }

// History exposes the current conversation (read-only use).
func (a *Agent) History() []llm.Message { return a.history }

// Reset clears the conversation.
func (a *Agent) Reset() { a.history = nil }

// Run processes one user message, driving the ReAct loop and emitting events.
// It blocks until the turn completes; callers typically run it in a goroutine.
func (a *Agent) Run(ctx context.Context, userInput string, emit func(Event)) {
	a.history = append(a.history, llm.Message{Role: llm.RoleUser, Content: userInput})

	// Effort level governs how hard the agent works this turn.
	maxSteps := a.effort.MaxSteps
	if maxSteps <= 0 {
		maxSteps = a.cfg.MaxSteps
	}
	maxTokens := a.effort.MaxTokens
	if maxTokens <= 0 {
		maxTokens = a.cfg.MaxTokens
	}
	// Cap to the current model's actual limit to avoid 400 errors.
	maxTokens = config.CappedMaxTokens(a.cfg, maxTokens)

	a.logger.Info("turn started",
		logging.F("input_len", len(userInput)),
		logging.F("effort", a.effort.Name),
		logging.F("max_steps", maxSteps))
	turnStart := time.Now()

	for step := 0; step < maxSteps; step++ {
		// Keep the conversation within the model's context budget.
		if a.ctxMgr != nil {
			if fitted, compacted, err := a.ctxMgr.Fit(a.history); err == nil {
				a.history = fitted
				if compacted {
					a.logger.Info("context compacted", logging.F("messages", len(fitted)))
				}
			}
		}

		req := llm.Request{
			Model:     config.EffectiveModel(a.cfg, a.effort.Name),
			System:    a.system,
			Messages:  a.history,
			Tools:     a.registry.Schemas(),
			MaxTokens: maxTokens,
			Stream:    true,
		}

		// Open the stream with retry/backoff on transient failures.
		var stream <-chan llm.StreamEvent
		err := retry.Do(ctx, a.retryPol, func(attempt int, delay time.Duration, e error) {
			a.logger.Warn("llm retry",
				logging.F("attempt", attempt),
				logging.F("delay_ms", delay.Milliseconds()),
				logging.F("err", e.Error()))
		}, func() error {
			s, e := a.client.Stream(ctx, req)
			if e != nil {
				return e
			}
			stream = s
			return nil
		})
		if err != nil {
			a.logger.Error("llm stream failed", logging.F("err", err.Error()))
			emit(Event{Kind: EventError, Text: err.Error()})
			return
		}

		var (
			assistantText string
			toolCalls     []llm.ToolCall
			usage         *llm.Usage
			truncated     bool
		)

		for ev := range stream {
			switch {
			case ev.Err != nil:
				a.logger.Error("stream error", logging.F("err", ev.Err.Error()))
				emit(Event{Kind: EventError, Text: ev.Err.Error()})
				return
			case ev.TextDelta != "":
				assistantText += ev.TextDelta
				emit(Event{Kind: EventText, Text: ev.TextDelta})
			case ev.ToolCall != nil:
				toolCalls = append(toolCalls, *ev.ToolCall)
				if ev.Truncated {
					truncated = true
				}
			case ev.Done:
				usage = ev.Usage
				if ev.Truncated {
					truncated = true
				}
			}
		}

		// Record the assistant turn (text + any tool calls).
		a.history = append(a.history, llm.Message{
			Role:      llm.RoleAssistant,
			Content:   assistantText,
			ToolCalls: toolCalls,
		})

		// No tool calls -> the model is done answering.
		if len(toolCalls) == 0 {
			a.logger.Info("turn complete",
				logging.F("steps", step+1),
				logging.F("ms", time.Since(turnStart).Milliseconds()))
			emit(Event{Kind: EventDone, Usage: usage})
			return
		}

		// Execute each tool call and feed results back.
		for _, call := range toolCalls {
			emit(Event{Kind: EventToolCall, ToolName: call.Name, ToolArgs: call.Args})
			a.logger.Info("tool call", logging.F("tool", call.Name))

			// If the model ran out of output budget mid-call, its argument JSON
			// is incomplete. Don't try to run it — that produced the cryptic
			// "unexpected end of JSON input". Feed back a clear, recoverable
			// instruction so the model splits the work instead of looping.
			if truncated && !json.Valid([]byte(call.Args)) {
				msg := "The previous tool call was cut off because it exceeded the output token limit, " +
					"so its arguments are incomplete. Do NOT resend the whole thing. Instead, for large files: " +
					"create the file with write_file using only the FIRST portion of the content, then append the " +
					"rest in multiple follow-up steps using append_file (or edit_file). Keep each single tool call small."
				a.logger.Warn("truncated tool args", logging.F("tool", call.Name), logging.F("args_len", len(call.Args)))
				emit(Event{Kind: EventToolDone, ToolName: call.Name, Result: msg, IsError: true})
				a.history = append(a.history, llm.Message{
					Role:       llm.RoleTool,
					ToolCallID: call.ID,
					ToolName:   call.Name,
					Content:    "Error: " + msg,
				})
				continue
			}

			res := a.registry.Execute(ctx, call)
			if res.IsError {
				a.logger.Warn("tool error", logging.F("tool", call.Name), logging.F("result", res.Content))
			}

			emit(Event{
				Kind:     EventToolDone,
				ToolName: call.Name,
				Result:   res.Content,
				IsError:  res.IsError,
			})

			a.history = append(a.history, llm.Message{
				Role:       llm.RoleTool,
				ToolCallID: call.ID,
				ToolName:   call.Name,
				Content:    res.Content,
			})
		}
		// Loop again so the model can react to the tool results.
	}

	a.logger.Warn("max steps reached", logging.F("steps", maxSteps))
	emit(Event{Kind: EventError, Text: "reached max steps without completion"})
}
