package tui

import "github.com/charmbracelet/lipgloss"

// Theme holds all styles used across the UI.
type Theme struct {
	User      lipgloss.Style
	Assistant lipgloss.Style
	Tool      lipgloss.Style
	ToolErr   lipgloss.Style
	Prompt    lipgloss.Style
	Border    lipgloss.Style
	Status    lipgloss.Style
	Title     lipgloss.Style
	Dim       lipgloss.Style
}

// DraculaTheme is the default color scheme.
func DraculaTheme() Theme {
	var (
		purple = lipgloss.Color("#bd93f9")
		pink   = lipgloss.Color("#ff79c6")
		green  = lipgloss.Color("#50fa7b")
		cyan   = lipgloss.Color("#8be9fd")
		red    = lipgloss.Color("#ff5555")
		gray   = lipgloss.Color("#6272a4")
		fg     = lipgloss.Color("#f8f8f2")
	)
	return Theme{
		User:      lipgloss.NewStyle().Foreground(cyan).Bold(true),
		Assistant: lipgloss.NewStyle().Foreground(fg),
		Tool:      lipgloss.NewStyle().Foreground(green),
		ToolErr:   lipgloss.NewStyle().Foreground(red),
		Prompt:    lipgloss.NewStyle().Foreground(pink).Bold(true),
		Border:    lipgloss.NewStyle().Foreground(purple),
		Status:    lipgloss.NewStyle().Foreground(gray),
		Title:     lipgloss.NewStyle().Foreground(purple).Bold(true),
		Dim:       lipgloss.NewStyle().Foreground(gray),
	}
}
