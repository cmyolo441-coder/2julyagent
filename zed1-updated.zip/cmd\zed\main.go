package main

import (
	"context"
	"fmt"
	"os"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/gjkjk/zed/internal/agent"
	"github.com/gjkjk/zed/internal/cache"
	"github.com/gjkjk/zed/internal/collab"
	"github.com/gjkjk/zed/internal/config"
	"github.com/gjkjk/zed/internal/dist"
	"github.com/gjkjk/zed/internal/index"
	"github.com/gjkjk/zed/internal/llm"
	"github.com/gjkjk/zed/internal/logging"
	"github.com/gjkjk/zed/internal/memory"
	"github.com/gjkjk/zed/internal/meta"
	"github.com/gjkjk/zed/internal/metrics"
	"github.com/gjkjk/zed/internal/plugin"
	"github.com/gjkjk/zed/internal/predict"
	"github.com/gjkjk/zed/internal/sandbox"
	"github.com/gjkjk/zed/internal/security"
	"github.com/gjkjk/zed/internal/session"
	"github.com/gjkjk/zed/internal/snapshot"
	"github.com/gjkjk/zed/internal/tools"
	"github.com/gjkjk/zed/internal/tui"
	"github.com/gjkjk/zed/internal/watcher"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "zed:", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	// Allow simple CLI overrides: zed --model X --provider Y
	parseFlags(cfg)

	if cfg.APIKey == "" {
		return fmt.Errorf("no API key set (export ZED_API_KEY or ANTHROPIC_API_KEY / OPENAI_API_KEY)")
	}

	// Structured file logging (never writes to the TUI's terminal).
	logger, err := logging.New(logging.Options{Level: logging.LevelInfo})
	if err != nil {
		return fmt.Errorf("init logging: %w", err)
	}
	defer logger.Close()
	logger.Info("zed starting", logging.F("provider", cfg.Provider), logging.F("model", cfg.Model))

	// Cache layer for LLM responses (3-10x speedup).
	cch := cache.New(5000)
	logger.Info("cache initialized", logging.F("max_entries", "5000"))

	client, err := llm.New(cfg)
	if err != nil {
		return fmt.Errorf("init llm: %w", err)
	}
	client = llm.WithCache(client, cch)

	// Enterprise subsystems.
	snapshots := snapshot.NewManager(200)
	policy := security.DefaultPolicy(cfg.WorkDir, cfg.AutoApply)
	sessions, err := session.NewStore("")
	if err != nil {
		logger.Warn("session store unavailable", logging.F("err", err.Error()))
	}

	// Zero-trust security sandbox.
	sbx := sandbox.New(cfg.WorkDir)

	// Code metrics dashboard.
	dash := metrics.New()

	// Intent prediction engine.
	eng := predict.New()

	// Plugin manager.
	pm := plugin.New()

	// Distributed agent network.
	net := dist.New()
	net.Register(&dist.Node{ID: "zed-local", Address: "localhost", Capacity: 5})

	// Collaboration session.
	collabSess := collab.NewSession()

	// File watcher for hot-reload.
	wtr := watcher.New(cfg.WorkDir, []string{".go", ".py", ".js", ".ts", ".jsx", ".tsx", ".rs"})
	wtr.OnChange(func(ev watcher.Event) {
		tests := watcher.RelevantTests(ev.Path)
		if len(tests) > 0 {
			logger.Info("file changed, relevant tests",
				logging.F("file", ev.Path),
				logging.F("tests", fmt.Sprintf("%v", tests)))
		}
	})
	go wtr.Start(context.Background())

	// Build the codebase index in the background so startup stays fast.
	idx := index.New(cfg.WorkDir)
	go func() {
		stats, err := idx.Build()
		if err != nil {
			logger.Warn("index build failed", logging.F("err", err.Error()))
			return
		}
		logger.Info("index built",
			logging.F("files", stats.Files),
			logging.F("symbols", stats.Symbols),
			logging.F("ms", stats.Duration.Milliseconds()))
	}()

	registry := buildRegistry(cfg, snapshots, idx, client, cch, sbx, dash, eng, pm, net, wtr, collabSess)
	ag := agent.New(cfg, client, registry)
	ag.SetSnapshots(snapshots)
	ag.SetPolicy(policy)
	ag.SetLogger(logger)

	model := tui.NewModel(cfg, ag, snapshots, sessions, idx, cch, sbx, dash, eng, pm, net, wtr, collabSess)
	// Note: we deliberately do NOT enable mouse capture (WithMouseCellMotion).
	// Capturing the mouse prevents the terminal's native text selection, so
	// users couldn't select/copy text. Leaving it off restores normal
	// click-drag selection and copy (Ctrl/Cmd+C, or the terminal's copy).
	p := tea.NewProgram(model, tea.WithAltScreen())
	_, err = p.Run()
	return err
}

// buildRegistry registers every tool the agent can use.
func buildRegistry(cfg *config.Config, snapshots *snapshot.Manager, idx *index.Index, client llm.Client, cch *cache.Cache, sbx *sandbox.Sandbox, dash *metrics.Dashboard, eng *predict.Engine, pm *plugin.Manager, net *dist.Network, wtr *watcher.Watcher, collabSess *collab.Session) *tools.Registry {
	r := tools.NewRegistry()
	wd := cfg.WorkDir

	// File operations.
	r.Register(&tools.ReadFile{WorkDir: wd})
	r.Register(&tools.WriteFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.AppendFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.EditFile{WorkDir: wd, Snapshots: snapshots})
	r.Register(&tools.ListDir{WorkDir: wd})

	// Search tools.
	r.Register(&tools.Grep{WorkDir: wd})
	r.Register(&tools.FindFiles{WorkDir: wd})
	r.Register(&tools.CodeSearch{Index: idx})
	r.Register(&tools.SymbolLookup{Index: idx})
	r.Register(&tools.SemanticSearch{Index: idx})

	// Shell (with sandbox command validation).
	r.Register(&tools.Shell{WorkDir: wd, Timeout: 4000 * time.Second, Sandbox: sbx})

	// Web search.
	r.Register(tools.NewWebSearch())

	// Persistent memory.
	mem := memory.New()
	r.Register(&tools.MemoryRemember{Store: mem})
	r.Register(&tools.MemoryRecall{Store: mem})

	// Multi-agent orchestration.
	r.Register(&tools.SpawnSwarm{Client: client, Registry: r})

	// AST code intelligence.
	r.Register(&tools.AnalyzeCode{WorkDir: wd})

	// Snapshot history + diff.
	r.Register(&tools.SnapshotHistory{Snapshots: snapshots})

	// Task decomposition.
	r.Register(&tools.DecomposeTask{})

	// Code quality analyzer.
	r.Register(&tools.CodeQuality{WorkDir: wd})

	// CI pipeline.
	r.Register(&tools.CIPipeline{WorkDir: wd})

	// Code scaffolding.
	r.Register(&tools.Scaffold{WorkDir: wd})

	// Profiling & benchmarks.
	r.Register(&tools.ProfileCode{WorkDir: wd})
	r.Register(&tools.ParseBenchmark{})

	// Code metrics dashboard.
	r.Register(&tools.CodeMetrics{Dashboard: dash})

	// Intent prediction.
	r.Register(&tools.PredictSuggest{Engine: eng})

	// Distributed network status.
	r.Register(&tools.DistStatus{Network: net})
	r.Register(&tools.DistSubmit{Network: net})

	// File watcher status.
	r.Register(&tools.WatcherStatus{Watcher: wtr})

	// Advanced enterprise tools.
	r.Register(&tools.SelfAnalyze{Profile: meta.New()})
	r.Register(&tools.ReasonTool{})
	r.Register(&tools.GitTool{WorkDir: wd})
	r.Register(&tools.FuzzTool{})
	r.Register(&tools.DiagramTool{WorkDir: wd})
	r.Register(&tools.SelfTestTool{})

	// Plugin executor — wraps plugin.Manager as a tool so the LLM can call plugins.
	r.Register(&tools.PluginExecute{Manager: pm})
	r.Register(&tools.PluginList{Manager: pm})

	return r
}

// parseFlags applies minimal command-line overrides.
func parseFlags(cfg *config.Config) {
	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--model":
			if i+1 < len(args) {
				cfg.Model = args[i+1]
				i++
			}
		case "--provider":
			if i+1 < len(args) {
				cfg.Provider = args[i+1]
				i++
			}
		}
	}
}
