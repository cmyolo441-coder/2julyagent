hello

# ZED — Elite Autonomous Software Engineering Agent

A terminal-native AI agent that thinks like a senior staff engineer, writes code like a senior developer, and debugs like a relentless debugger. Built in Go with a beautiful Bubble Tea TUI.

## Features

- **Autonomous Goal Mode**: Give it a high-level goal — it researches, plans, builds, tests, and verifies end-to-end
- **Ultra Combo Max (100×)**: Enterprise-grade autonomous engineering with swarm intelligence
- **Self-Healing Debug**: Automatically detects build failures and fixes them in a loop
- **Multi-Agent Swarm**: Spawns parallel sub-agents for independent sub-tasks
- **Real CI Pipeline**: Lint → Build → Test → Security scan, auto-detected per language
- **Code Quality Analysis**: OWASP Top 10, code smells, duplication, complexity scoring
- **AST Code Intelligence**: Dead code detection, unused imports, circular dependencies
- **Cybersecurity Mode**: OWASP testing, STRIDE threat modeling, vulnerability assessment
- **Persistent Memory**: Stores facts, patterns, and decisions across sessions
- **Web Search**: Real-time documentation, API lookup, error resolution
- **Fuzz Testing**: Generates property-based fuzz tests for edge case discovery
- **Architecture Diagrams**: Auto-generates Mermaid dependency/call/class graphs
- **Snapshot Undo/Redo**: Full file change history with rollback capability
- **Session Management**: Save, list, and resume conversations
- **LLM Response Cache**: TTL-based SHA-256 cache, 3-10× speedup and cost reduction
- **Security Sandbox**: Zero-trust staged file writes, command allowlist, path validation
- **Profiling & Benchmarks**: Auto-detect profiling commands per language, parse Go benchmark output
- **Code Metrics Dashboard**: Tracks complexity, coverage, tech debt, and project health over time
- **Intent Prediction**: Learns user patterns and predicts next actions
- **Hot-Loadable Plugins**: Register custom tools at runtime without restarting
- **Distributed Agent Network**: Multi-instance task queue with work stealing
- **Real-Time Collaboration**: CRDT-based multi-user sessions with file locking
- **File Watcher**: Polls for file changes and auto-discovers relevant tests

## Effort Levels

| Level | Multiplier | Features |
|-------|-----------|----------|
| `normal` | 1× | Fast, balanced — everyday edits and questions |
| `ultraeffort` | 1× | Deep reasoning + planning + self-verify |
| `ultramax` | 40× | Exhaustive research + swarm + security + CI |
| `ultracombomax` | 100× | Enterprise autonomous engineering + goal mode |
| `goal` | 100× | Ultra Combo Max + maximum autonomous execution |

## Quick Start

```bash
# Set your API key
export ZED_API_KEY="your-key-here"

# Build and run
go build -o zed ./cmd/zed
./zed

# Or use slash commands inside the TUI
/effort goal          # switch to goal mode
/effort ultracombomax # enterprise autonomous mode
/goal <task>          # autonomous end-to-end execution
/cyber                # cybersecurity mode
/model <name>         # switch LLM model
/cache                # LLM response cache stats
/sandbox              # security sandbox status
/collab               # collaboration session status
/dist                 # distributed network status
/metrics              # code metrics dashboard
/watcher              # file watcher status
/plugin               # list plugins
```

## Supported Languages

Go, Node.js, Python, Rust, Java (Maven/Gradle), C# (.NET), Ruby — with auto-detection for build, test, lint, and format commands.

## Architecture

```
cmd/zed/          — CLI entry point
internal/
  agent/          — ReAct loop, system prompts, self-healing debug
  config/         — Configuration, effort levels, model registry
  tools/          — 25+ tools (file ops, search, shell, CI, quality, security, profile, metrics, predict, dist, plugin, watcher)
  llm/            — OpenAI-compatible + Anthropic streaming clients with response cache
  swarm/          — Multi-agent parallel orchestration
  ci/             — CI pipeline detection and execution
  quality/        — Static analysis, OWASP scanning, code smells
  snapshot/       — File change history with undo/redo
  session/        — Conversation persistence
  index/          — Codebase TF-IDF vector store for semantic search
  memory/         — Persistent cross-session memory
  planner/        — Task decomposition and planning
  fuzz/           — Fuzz test generation
  diagram/        — Architecture diagram generation
  security/       — Security policy enforcement
  vcs/            — Git automation
  cache/          — TTL-based LLM response cache
  sandbox/        — Zero-trust staged file writes and command allowlist
  profiler/       — Performance profiling and benchmark parsing
  metrics/        — Code metrics dashboard and health tracking
  predict/        — Intent prediction engine
  plugin/         — Hot-loadable plugin system
  dist/           — Distributed agent network with work stealing
  collab/         — CRDT-based real-time collaboration
  watcher/        — File system watcher for hot-reload
  tui/            — Bubble Tea terminal UI
```