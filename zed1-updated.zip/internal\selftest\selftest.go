// Package selftest provides self-testing code generation. The agent writes
// tests alongside code, targets a coverage goal, and auto-discovers edge cases.
package selftest

import (
	"fmt"
	"strings"
)

// TestPlan describes a testing strategy for a function or module.
type TestPlan struct {
	Target      string
	Language    string
	CoverageGoal float64 // 0-100
	Cases       []TestCase
}

// TestCase is a single test to generate.
type TestCase struct {
	Name        string
	Description string
	Input       string
	Expected    string
	Type        string // "basic", "edge", "error", "property"
}

// Generate creates a test plan for a function.
func Generate(funcName, language string, coverageGoal float64) *TestPlan {
	plan := &TestPlan{
		Target:       funcName,
		Language:     language,
		CoverageGoal: coverageGoal,
	}

	// Basic cases.
	plan.Cases = append(plan.Cases, TestCase{
		Name:        "basic",
		Description: "Standard input with expected output",
		Type:        "basic",
	})

	// Edge cases (auto-discovered).
	plan.Cases = append(plan.Cases,
		TestCase{Name: "empty_input", Description: "Empty/nil input", Type: "edge"},
		TestCase{Name: "max_input", Description: "Maximum size input", Type: "edge"},
		TestCase{Name: "min_input", Description: "Minimum valid input", Type: "edge"},
		TestCase{Name: "unicode", Description: "Unicode/special characters", Type: "edge"},
	)

	// Error cases.
	plan.Cases = append(plan.Cases,
		TestCase{Name: "invalid_input", Description: "Invalid input should return error", Type: "error"},
		TestCase{Name: "nil_input", Description: "Nil pointer should not panic", Type: "error"},
	)

	// Property-based cases.
	plan.Cases = append(plan.Cases,
		TestCase{Name: "idempotent", Description: "f(f(x)) == f(x) if applicable", Type: "property"},
		TestCase{Name: "deterministic", Description: "Same input → same output", Type: "property"},
	)

	return plan
}

// RenderGo generates Go test code from a plan.
func (p *TestPlan) RenderGo() string {
	var b strings.Builder
	b.WriteString(fmt.Sprintf("package %s_test\n\n", p.Target))
	b.WriteString("import \"testing\"\n\n")

	for _, tc := range p.Cases {
		b.WriteString(fmt.Sprintf("func Test%s_%s(t *testing.T) {\n", p.Target, tc.Name))
		b.WriteString(fmt.Sprintf("\t// %s\n", tc.Description))
		b.WriteString("\t// TODO: implement test\n")
		b.WriteString("\tt.Skip(\"auto-generated — implement me\")\n")
		b.WriteString("}\n\n")
	}
	return b.String()
}

// RenderPython generates Python test code from a plan.
func (p *TestPlan) RenderPython() string {
	var b strings.Builder
	b.WriteString("import pytest\n\n")

	for _, tc := range p.Cases {
		b.WriteString(fmt.Sprintf("def test_%s_%s():\n", p.Target, tc.Name))
		b.WriteString(fmt.Sprintf("    \"\"\"%s\"\"\"\n", tc.Description))
		b.WriteString("    # TODO: implement test\n")
		b.WriteString("    pytest.skip(\"auto-generated — implement me\")\n\n")
	}
	return b.String()
}

// Render returns test code in the appropriate language.
func (p *TestPlan) Render() string {
	switch p.Language {
	case "go":
		return p.RenderGo()
	case "python":
		return p.RenderPython()
	default:
		return p.RenderGo()
	}
}

// Summary returns a description of the test plan.
func (p *TestPlan) Summary() string {
	var b strings.Builder
	fmt.Fprintf(&b, "🧪 Self-Test Plan for %s (%s)\n", p.Target, p.Language)
	fmt.Fprintf(&b, "   Coverage goal: %.0f%%\n", p.CoverageGoal)
	fmt.Fprintf(&b, "   Test cases: %d\n\n", len(p.Cases))
	for _, tc := range p.Cases {
		emoji := "✓"
		switch tc.Type {
		case "edge":
			emoji = "🔍"
		case "error":
			emoji = "⚠️"
		case "property":
			emoji = "🧬"
		}
		fmt.Fprintf(&b, "  %s %s: %s\n", emoji, tc.Name, tc.Description)
	}
	return b.String()
}
