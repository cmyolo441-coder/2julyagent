package config

import "strings"

// Effort selects how hard ZED works on a task. Higher levels unlock deeper
// reasoning, more ReAct iterations, larger token budgets, up-front planning,
// and self-verification loops — trading speed and cost for capability on
// increasingly complex, real-world projects.
type Effort struct {
	// Name is the canonical identifier (also the /command alias).
	Name string
	// Label is a short human-friendly title shown in the UI.
	Label string
	// Multiplier is a rough "how much more advanced" factor vs. normal,
	// used purely for display (e.g. "40×").
	Multiplier int
	// MaxSteps caps the ReAct loop for this level.
	MaxSteps int
	// MaxTokens caps output tokens per model turn.
	MaxTokens int
	// FastModel overrides the primary model when set. Goal mode and similar
	// long-running levels benefit from a fast, cheap model for low latency.
	FastModel string
	// PlanFirst makes the agent produce a structured plan before acting.
	PlanFirst bool
	// SelfVerify makes the agent build/test its own work and fix regressions.
	SelfVerify bool
	// DeepResearch makes the agent investigate the codebase end-to-end first.
	DeepResearch bool
	// GoalMode turns on fully autonomous, end-to-end goal execution.
	GoalMode bool
	// Description is a one-line summary of when to use this level.
	Description string

	// === REAL EFFORT BEHAVIOR FIELDS ===
	// These control actual agent behavior — not just display.

	// ParallelTools allows parallel tool execution (multiple tools per step).
	ParallelTools bool
	// UseSwarm enables multi-agent orchestration for complex tasks.
	UseSwarm bool
	// SwarmSize is the max number of parallel sub-agents to spawn.
	SwarmSize int
	// AutoDebug enables self-healing: auto build/test after file changes.
	AutoDebug bool
	// MaxDebugRetries is how many times to retry fixing a failing build.
	MaxDebugRetries int
	// RunQualityCheck runs code quality analysis after changes.
	RunQualityCheck bool
	// RunSecurityScan runs security vulnerability scanning after changes.
	RunSecurityScan bool
	// ContextBudgetMultiplier scales the context window (1.0 = model default).
	ContextBudgetMultiplier float64
	// Temperature controls LLM creativity (0 = deterministic, 1 = creative).
	Temperature float64
	// EnableWebSearch allows the agent to search the web for information.
	EnableWebSearch bool
	// EnableMemory allows the agent to use persistent memory.
	EnableMemory bool
	// EnableAST enables AST-based code analysis.
	EnableAST bool
	// EnableCI runs the full CI pipeline after changes.
	EnableCI bool
	// VerbosePlanning produces detailed step-by-step plans.
	VerbosePlanning bool
	// MaxFileReads limits how many files to read per turn (0 = unlimited).
	MaxFileReads int
}

// Effort level names. These double as slash-command aliases.
const (
	EffortNormal        = "normal"
	EffortUltra         = "ultraeffort"
	EffortUltraMax      = "ultramax"
	EffortUltraComboMax = "ultracombomax"
	EffortGoal          = "goal"
)

// DefaultEffort is used when nothing is configured.
const DefaultEffort = EffortNormal

// efforts is the ordered catalog of available effort levels.
var efforts = []Effort{
	{
		Name:        EffortNormal,
		Label:       "Normal",
		Multiplier:  1,
		MaxSteps:    10000,
		MaxTokens:   128000,
		Description: "Fast, balanced. Everyday edits, questions, and small tasks.",
		// Real behavior: minimal overhead, fast responses
		ParallelTools:            true,
		UseSwarm:                 false,
		SwarmSize:                0,
		AutoDebug:                false,
		MaxDebugRetries:          0,
		RunQualityCheck:          false,
		RunSecurityScan:          false,
		ContextBudgetMultiplier:  1.0,
		Temperature:              0.3,
		EnableWebSearch:          false,
		EnableMemory:             false,
		EnableAST:                false,
		EnableCI:                 false,
		VerbosePlanning:          false,
		MaxFileReads:             10,
	},
	{
		Name:        EffortUltra,
		Label:       "Ultra Effort",
		Multiplier:  1,
		MaxSteps:    10000,
		MaxTokens:   128000,
		PlanFirst:   true,
		SelfVerify:  true,
		Description: "Deep reasoning + planning + self-verify. For advanced, complex projects.",
		// Real behavior: planning + self-verify + auto-debug
		ParallelTools:            true,
		UseSwarm:                 false,
		SwarmSize:                0,
		AutoDebug:                true,
		MaxDebugRetries:          3,
		RunQualityCheck:          true,
		RunSecurityScan:          false,
		ContextBudgetMultiplier:  1.0,
		Temperature:              0.2,
		EnableWebSearch:          true,
		EnableMemory:             true,
		EnableAST:                true,
		EnableCI:                 false,
		VerbosePlanning:          true,
		MaxFileReads:             20,
	},
	{
		Name:         EffortUltraMax,
		Label:        "Ultra Max",
		Multiplier:   40,
		MaxSteps:     10000,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		Description:  "40× — exhaustive planning, research, and verification for large complex systems.",
		// Real behavior: deep research + swarm + security + CI
		ParallelTools:            true,
		UseSwarm:                 true,
		SwarmSize:                3,
		AutoDebug:                true,
		MaxDebugRetries:          5,
		RunQualityCheck:          true,
		RunSecurityScan:          true,
		ContextBudgetMultiplier:  1.5,
		Temperature:              0.1,
		EnableWebSearch:          true,
		EnableMemory:             true,
		EnableAST:                true,
		EnableCI:                 true,
		VerbosePlanning:          true,
		MaxFileReads:             50,
	},
	{
		Name:         EffortUltraComboMax,
		Label:        "Ultra Combo Max",
		Multiplier:   100,
		MaxSteps:     10000,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		Description:  "100× — enterprise-grade, real-world autonomous engineering at maximum depth.",
		// Real behavior: everything on, maximum swarm, maximum retries
		ParallelTools:            true,
		UseSwarm:                 true,
		SwarmSize:                5,
		AutoDebug:                true,
		MaxDebugRetries:          10,
		RunQualityCheck:          true,
		RunSecurityScan:          true,
		ContextBudgetMultiplier:  2.0,
		Temperature:              0.05,
		EnableWebSearch:          true,
		EnableMemory:             true,
		EnableAST:                true,
		EnableCI:                 true,
		VerbosePlanning:          true,
		MaxFileReads:             0, // unlimited
	},
	{
		Name:         EffortGoal,
		Label:        "Goal Mode",
		Multiplier:   100,
		MaxSteps:     10000,
		MaxTokens:    128000,
		PlanFirst:    true,
		SelfVerify:   true,
		DeepResearch: true,
		GoalMode:     true,
		Description:  "100× — Ultra Combo Max + autonomous goal execution. Researches, plans, builds end-to-end, self-detects and fixes bugs. Maximum power.",
		// Real behavior: same as ultracombomax + goal mode autonomy, maxed out
		ParallelTools:            true,
		UseSwarm:                 true,
		SwarmSize:                10,
		AutoDebug:                true,
		MaxDebugRetries:          20,
		RunQualityCheck:          true,
		RunSecurityScan:          true,
		ContextBudgetMultiplier:  3.0,
		Temperature:              0.02,
		EnableWebSearch:          true,
		EnableMemory:             true,
		EnableAST:                true,
		EnableCI:                 true,
		VerbosePlanning:          true,
		MaxFileReads:             0, // unlimited
	},
}

// Efforts returns the catalog of effort levels in display order.
func Efforts() []Effort { return efforts }

// LookupEffort returns the effort profile for a name (case-insensitive).
// The second return value reports whether the name was recognized.
func LookupEffort(name string) (Effort, bool) {
	n := strings.ToLower(strings.TrimSpace(name))
	for _, e := range efforts {
		if e.Name == n {
			return e, true
		}
	}
	return efforts[0], false
}

// EffortProfile returns the profile for a name, falling back to Normal.
func EffortProfile(name string) Effort {
	e, _ := LookupEffort(name)
	return e
}

// IsGoalEffort reports whether the given effort level has goal-mode autonomy
// enabled. Both "goal" and "ultracombomax" qualify — selecting either one
// engages fully autonomous, end-to-end goal execution.
func IsGoalEffort(e Effort) bool {
	return e.GoalMode
}

// IsGoalEffortName is a convenience wrapper for callers that only have the
// effort name string (e.g. from config).
func IsGoalEffortName(name string) bool {
	e, ok := LookupEffort(name)
	if !ok {
		return false
	}
	return e.GoalMode
}
