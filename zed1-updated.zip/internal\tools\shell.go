package tools

import (
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"runtime"
	"time"

	"github.com/gjkjk/zed/internal/sandbox"
)

// Shell runs shell commands cross-platform (PowerShell on Windows, sh elsewhere).
type Shell struct {
	WorkDir string
	Timeout time.Duration
	Sandbox *sandbox.Sandbox
}

func (t *Shell) Name() string { return "run_shell" }
func (t *Shell) Description() string {
	return "Execute a shell command in the project directory and return its combined stdout/stderr. Use for builds, tests, git, and any CLI task."
}
func (t *Shell) RequiresApproval() bool { return true }
func (t *Shell) Schema() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"command": map[string]any{"type": "string", "description": "The shell command to run."},
		},
		"required": []string{"command"},
	}
}

func (t *Shell) Execute(ctx context.Context, args string) (string, error) {
	var a struct {
		Command string `json:"command"`
	}
	if err := parseArgs(args, &a); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}
	if a.Command == "" {
		return "", fmt.Errorf("empty command")
	}
	if t.Sandbox != nil && !t.Sandbox.IsCommandAllowed(a.Command) {
		return "", fmt.Errorf("command %q is not in the sandbox allowlist", a.Command)
	}

	timeout := t.Timeout
	if timeout == 0 {
		timeout = 5 * time.Minute
	}
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	var cmd *exec.Cmd
	if runtime.GOOS == "windows" {
		cmd = exec.CommandContext(cctx, "powershell", "-NoProfile", "-NonInteractive", "-Command", a.Command)
	} else {
		cmd = exec.CommandContext(cctx, "sh", "-c", a.Command)
	}
	cmd.Dir = t.WorkDir

	var buf bytes.Buffer
	cmd.Stdout = &buf
	cmd.Stderr = &buf
	err := cmd.Run()

	out := buf.String()
	if cctx.Err() == context.DeadlineExceeded {
		return out, fmt.Errorf("command timed out after %s", timeout)
	}
	if err != nil {
		return fmt.Sprintf("[exit error: %v]\n%s", err, out), nil
	}
	if out == "" {
		out = "(no output)"
	}
	return out, nil
}
