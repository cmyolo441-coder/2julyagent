// Package sandbox implements a zero-trust security sandbox. Tool calls
// execute in an isolated environment where file changes are staged (not
// applied to disk until approved), and shell commands run with restricted
// permissions.
package sandbox

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

// StagedChange is a file modification that hasn't been applied yet.
type StagedChange struct {
	Path     string
	Content  []byte
	Original []byte // empty if file didn't exist
	Op       string // "create", "modify", "delete"
}

// Sandbox isolates file changes and restricts shell commands.
type Sandbox struct {
	mu      sync.Mutex
	root    string
	staged  map[string]*StagedChange
	allowed map[string]bool // allowed shell commands
}

// New creates a sandbox rooted at the project directory.
func New(root string) *Sandbox {
	s := &Sandbox{
		root:   root,
		staged: map[string]*StagedChange{},
		allowed: map[string]bool{
			"go": true, "python": true, "node": true, "npm": true,
			"git": true, "ls": true, "cat": true, "echo": true,
			"test": true, "cargo": true, "rustc": true, "make": true,
			"gofmt": true, "golint": true, "eslint": true, "prettier": true,
		},
	}
	return s
}

// StageWrite stages a file write without applying it.
func (s *Sandbox) StageWrite(path string, content []byte) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	abs := s.resolve(path)
	original, _ := os.ReadFile(abs)
	op := "modify"
	if original == nil {
		op = "create"
	}
	s.staged[abs] = &StagedChange{
		Path:     abs,
		Content:  content,
		Original: original,
		Op:       op,
	}
	return nil
}

// StageDelete stages a file deletion.
func (s *Sandbox) StageDelete(path string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	abs := s.resolve(path)
	original, _ := os.ReadFile(abs)
	s.staged[abs] = &StagedChange{
		Path:     abs,
		Original: original,
		Op:       "delete",
	}
	return nil
}

// Commit applies all staged changes to disk.
func (s *Sandbox) Commit() ([]string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var applied []string
	for path, change := range s.staged {
		switch change.Op {
		case "create", "modify":
			if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
				return applied, err
			}
			if err := os.WriteFile(path, change.Content, 0644); err != nil {
				return applied, err
			}
		case "delete":
			if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
				return applied, err
			}
		}
		applied = append(applied, fmt.Sprintf("%s: %s", change.Op, path))
		delete(s.staged, path)
	}
	return applied, nil
}

// Rollback discards all staged changes.
func (s *Sandbox) Rollback() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.staged = map[string]*StagedChange{}
}

// Staged returns all pending changes.
func (s *Sandbox) Staged() []*StagedChange {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []*StagedChange
	for _, c := range s.staged {
		out = append(out, c)
	}
	return out
}

// IsCommandAllowed checks if a shell command is in the allowlist.
func (s *Sandbox) IsCommandAllowed(cmd string) bool {
	parts := strings.Fields(cmd)
	if len(parts) == 0 {
		return false
	}
	base := filepath.Base(parts[0])
	// Strip .exe on Windows.
	base = strings.TrimSuffix(base, ".exe")
	return s.allowed[base]
}

// ValidatePath checks that a path is within the sandbox root.
func (s *Sandbox) ValidatePath(path string) error {
	abs := s.resolve(path)
	if !strings.HasPrefix(abs, s.root) {
		return fmt.Errorf("path %q is outside the sandbox root", path)
	}
	return nil
}

func (s *Sandbox) resolve(path string) string {
	if filepath.IsAbs(path) {
		return path
	}
	return filepath.Join(s.root, path)
}

// Summary returns a description of the sandbox state.
func (s *Sandbox) Summary() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return fmt.Sprintf("🔒 Sandbox: %d staged changes, %d allowed commands",
		len(s.staged), len(s.allowed))
}
